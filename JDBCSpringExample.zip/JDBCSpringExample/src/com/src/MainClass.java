package com.src;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dao.StudentDao;
import com.model.Student;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		StudentDao sdao=(StudentDao) context.getBean("studdao");
		
        int status=sdao.saveStudent(new Student(11,"abishek","kerala",86131245));
		if(status>0)
		{
			System.out.println("insterted values");
		}
		else
		{
			System.out.println("cant insert values");
		}
		
		status=sdao.deleteStudent(new Student(105,"","",0));
		if(status>0)
		{
			System.out.println("value deleted");
		}
		else
		{
			System.out.println("cannot delete value");
		}
		
		status=sdao.updateStudent(new Student(108,"","",0));
		if(status>0)
		{
			System.out.println("value updated");
		}
		else
		{
			System.out.println("cannot update value");
		}

	}

}
