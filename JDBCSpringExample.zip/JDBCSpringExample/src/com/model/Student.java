package com.model;

public class Student {

	private int studentid;
	private String studentname;
	private String studentcity;
	private int studentmobno;
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(int studentid, String studentname, String studentcity, int studentmobno) {
		super();
		this.studentid = studentid;
		this.studentname = studentname;
		this.studentcity = studentcity;
		this.studentmobno = studentmobno;
	}
	public int getStudentid() {
		return studentid;
	}
	public String getStudentname() {
		return studentname;
	}
	public String getStudentcity() {
		return studentcity;
	}
	public long getStudentmobno() {
		return studentmobno;
	}
	
	
}
