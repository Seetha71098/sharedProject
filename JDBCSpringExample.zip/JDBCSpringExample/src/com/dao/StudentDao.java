package com.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.model.Student;

public class StudentDao {
private JdbcTemplate jdbctemp;
public void setJdbctemp(JdbcTemplate jdbctemp)
{
	this.jdbctemp=jdbctemp;
	
}

public int saveStudent(Student s)
{
	String sql="insert into Studentdb values("+s.getStudentid()+",'"+s.getStudentname()+"',"+s.getStudentcity()+",'"+s.getStudentmobno()+")";
	return jdbctemp.update(sql);
}

public int updateStudent(Student s)
{
	String sql="update studentdb set studentname='mahalakshmi' where studentid="+s.getStudentid();
	return jdbctemp.update(sql);
}

public int deleteStudent(Student s)
{
	String sql="delete from studentdb where studentid="+s.getStudentid();
	return jdbctemp.update(sql);
}
}
