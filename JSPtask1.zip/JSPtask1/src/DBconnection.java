
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class DBconnection {
	Connection con;

	public PreparedStatement getPreparedStatement1(String sql) throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		String url="jdbc:mysql://localhost:3306/seethadb";
		String username="seetha";
		String password = "seetharamesh";
		con = DriverManager.getConnection(url,username,password);
		PreparedStatement ps= con.prepareStatement(sql);
		return ps;
	}
	
	public Statement getStatement1() throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		String url="jdbc:mysql://localhost:3306/seethadb";
		String username="seetha";
		String password = "seetharamesh";
		con = DriverManager.getConnection(url,username,password);
		Statement ps= con.createStatement();
		return ps;
	}
}
